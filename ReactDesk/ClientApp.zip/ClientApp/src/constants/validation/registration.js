﻿export const usernameConstants = {
    USERNAME_MIN_LENGTH: 3,
    USERNAME_MAX_LENGTH: 50

}